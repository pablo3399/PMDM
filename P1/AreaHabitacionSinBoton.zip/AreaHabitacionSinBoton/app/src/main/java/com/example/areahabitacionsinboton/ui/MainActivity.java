package com.example.areahabitacionsinboton.ui;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.areahabitacion.ui.R;
import com.example.areahabitacionsinboton.core.CalcularArea;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText largoET = this.findViewById(R.id.largo);
        EditText anchoET = this.findViewById(R.id.ancho);
        TextView contador = this.findViewById(R.id.largoTV);

        largoET.setOnKeyListener(new View.OnKeyListener() {

            public boolean onKey(View arg0, int arg1, KeyEvent arg2) {
                MainActivity.this.mostrarResultado();
                return false;}});

        anchoET.setOnKeyListener(new View.OnKeyListener() {

            public boolean onKey(View arg0, int arg1, KeyEvent arg2) {
                MainActivity.this.mostrarResultado();
                    return false;}

    });}


    public void mostrarResultado() {

        EditText largoET = this.findViewById(R.id.largo);
        EditText anchoET = this.findViewById(R.id.ancho);
        TextView lblResult = this.findViewById(R.id.lblResult);

        try{

            if(largoET.getText().toString().isEmpty() && anchoET.getText().toString().isEmpty()){
                lblResult.setText(R.string.result);
            }else if(largoET.getText().toString().isEmpty() || anchoET.getText().toString().isEmpty()){
                lblResult.setText(R.string.label_default_result);
            }else{
                float largo = Float.parseFloat(largoET.getText().toString());
                float ancho = Float.parseFloat(anchoET.getText().toString());
                float res;
                res = CalcularArea.calcularArea(largo,ancho);
                String resultado = String.valueOf(res);

                lblResult.setText(resultado + " " + "m^2");
            }



        } catch (NumberFormatException e) {
            lblResult.setText(R.string.error);

        }

        return;}

}
