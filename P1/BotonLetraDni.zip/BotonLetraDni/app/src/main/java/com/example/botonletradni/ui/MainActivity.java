package com.example.botonletradni.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.botonletradni.core.LetraDni;


public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

            }


    public void mostrarResultado(View x) {


        EditText editableDni = (EditText) this.findViewById(R.id.editableDni);
        TextView lblResult = (TextView) this.findViewById(R.id.lblResult);
        String incorrecto = getString(R.string.incorrecto);
        int length = editableDni.getText().length();

        if( length == 8){
        try {
            int dni = Integer.parseInt(editableDni.getText().toString());

            char Letra = LetraDni.calcularDni(dni);
            lblResult.setText(Character.toString(Letra));
        } catch (NumberFormatException e) {

            lblResult.setText(incorrecto);
        }

        return;}
        else{
            lblResult.setText(incorrecto);
            return;
        }

    }
}


