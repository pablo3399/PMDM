package com.example.botonletradni.core;

public class LetraDni {

    public static final String NIF_STRING_ASSOCIATING = "trwagmyfpdxbnjzsqvhlcke";


    public static char calcularDni(int dni) {

        return NIF_STRING_ASSOCIATING.charAt(dni % 23);
    }
}

