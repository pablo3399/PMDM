package com.example.letradni.ui;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.letradni.core.LetraDNI;

public class mainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText editableDni = findViewById(R.id.editableDni);

        editableDni.setOnKeyListener(new View.OnKeyListener() {

            public boolean onKey(View arg0, int arg1, KeyEvent arg2) {
                mainActivity.this.mostrarResultado();
                return false;


            }
        });
    }

    public void mostrarResultado() {


            EditText editableDni = (EditText) this.findViewById(R.id.editableDni);
            TextView lblResult = (TextView) this.findViewById(R.id.lblResult);

        try {
            int dni = Integer.parseInt(editableDni.getText().toString());

            char Letra = LetraDNI.calcularDni(dni);
            lblResult.setText(Character.toString(Letra));
        } catch (NumberFormatException e) {

            lblResult.setText(R.string.label_default_result);
        }

        return;

    }
}


