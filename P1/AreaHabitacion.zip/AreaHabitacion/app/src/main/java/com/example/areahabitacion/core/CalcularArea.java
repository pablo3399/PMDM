package com.example.areahabitacion.core;

public class CalcularArea {


    public static float calcularArea(float area1, float area2) {

        return (area1 * area2);
    }

}
