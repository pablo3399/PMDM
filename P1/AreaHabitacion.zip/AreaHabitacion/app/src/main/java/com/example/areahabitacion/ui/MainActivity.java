package com.example.areahabitacion.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.areahabitacion.core.CalcularArea;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }


    public void mostrarResultado(View x) {


        EditText largoET = this.findViewById(R.id.largo);
        EditText anchoET = this.findViewById(R.id.ancho);
        TextView lblResult = this.findViewById(R.id.lblResult);



        float largo = Float.parseFloat(largoET.getText().toString());
        float ancho = Float.parseFloat(anchoET.getText().toString());


        try{
                float res = CalcularArea.calcularArea(largo,ancho);
                String resultado = String.valueOf(res);

                lblResult.setText(resultado + " " + "m^2");

            } catch (NumberFormatException e) {

                lblResult.setText(R.string.label_default_result);
            }

            return;}

    }
